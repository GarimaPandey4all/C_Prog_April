#include <stdio.h>
#include <stdlib.h>

int main()
{
    int count = 10, x;

    int *pcount = &count;

    x = *pcount;

    printf("value is: %d\n", *pcount); // 10

    printf("X is: %d\n", x); // 10

    printf("Count is: %d", count); // 10

    return 0;
}
