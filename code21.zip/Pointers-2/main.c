#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 100;

    int *pvalue = NULL;

    pvalue = &value;

    printf("Value is: %d\n", *pvalue); // 100

    *pvalue = 200; // value = 200

    printf("Value is: %d\n", *pvalue); // 200

    printf("Value is: %d\n", value); // 200

    return 0;
}
