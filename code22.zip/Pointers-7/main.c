#include <stdio.h>
#include <stdlib.h>

/*
    Pointer to a constant - value can't be changed
    Constant Pointer - address can't be changed

*/

int main()
{
    const int value = 10;
    int number = 20;

//    pointer to a constant
    //const int *pvalue = NULL;

    //Constant Pointer
    //int *const pvalue = &value;

    //Pointer to a constant and constant pointer
    const int *const pvalue = &value;

    //pvalue = &value;

    printf("value is: %d\n", *pvalue);

    //*pvalue = 30;//error

    //pvalue = &number;//error

    //value = 30; // error

    return 0;
}
