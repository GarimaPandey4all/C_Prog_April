#include <stdio.h>
#include <stdlib.h>

/*
    int arr[5];

    arr or &arr[0] - base address
*/

int main()
{
    int arr[5];
    int i;

    printf("Enter values in an array:");
    for(i = 0; i < 5; i++)
    {
        scanf("%d", (arr + i));
    }

    printf("Values in an array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\t", *(arr + i));
    }

    return 0;
}
