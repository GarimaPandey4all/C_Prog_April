#include <stdio.h>
#include <stdlib.h>

int main()
{
    int books[3][3], i, j;

    printf("Enter books:");
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            scanf("%d", &books[i][j]);
        }
    }

    printf("Books are:\n");
    for(i = 0; i < 3; i++)
    {
        for(j = 0; j < 3; j++)
        {
            printf("%d\t", books[i][j]);
        }
        printf("\n");
    }

    return 0;
}
