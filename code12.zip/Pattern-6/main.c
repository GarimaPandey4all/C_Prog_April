#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i, j, temp;

    for(i = 69; i >= 65; i--)
    {
        for(temp = 69; temp >= i; temp--)
        {
            printf(" ");
        }
        for(j = 65; j <= i; j++)
        {
            printf("%c", j);
        }
        printf("\n");
    }

    return 0;
}
