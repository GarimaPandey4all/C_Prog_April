#include <stdio.h>
#include <stdlib.h>

/*
    Calloc()

    Calloc stands for Contiguous allocation

    The malloc() function allocates memory and leaves the memory uninitialized.
    Whereas, the calloc() function allocation memory and initialized all bits to zero.

    Syntax:

    ptr = (casttype *)calloc(n, sizeof());

*/

int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    //Memory Allocation
    text = (char *)calloc(size, sizeof(char));

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    //Memory Deallocation
    free(text);
    text = NULL;

    return 0;
}
