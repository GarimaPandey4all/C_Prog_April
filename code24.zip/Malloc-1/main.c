#include <stdio.h>
#include <stdlib.h>

/*
    Malloc()

    Malloc stands for memory allocation

    The malloc() function reserves the block of memory of the number of bytes.
    And, it returns a pointer of void which can be casted/conversion
    into pointers of any data type.

    Syntax:

    ptr = (casttype *)malloc(size);

*/

int main()
{
    int size;
    char *text = NULL;

    printf("Enter limit of the text:");
    scanf("%d", &size);

    //Memory Allocation
    text = (char *)malloc(size * sizeof(char));

    if(text != NULL)
    {
        printf("Enter some text:");
        scanf(" ");
        gets(text);

        printf("Inputted text is: %s", text);
    }

    //Memory Deallocation
    free(text);
    text = NULL;

    return 0;
}
