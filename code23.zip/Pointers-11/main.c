#include <stdio.h>
#include <stdlib.h>

struct Date {

    int day;
    int month;
    int year;
};
//}date1, date2, date3;

struct Date date1, *pdate;

int main()
{
  //struct Date date1;

  pdate = &date1;

  pdate->day = 20;
  (*pdate).month = 5;
  pdate->year = 2021;

  printf("Day = %d, Month = %d, Year = %d\n", pdate->day, pdate->month, (*pdate).year);

    return 0;
}
