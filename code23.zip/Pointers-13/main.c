#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x, y;

    printf("Enter any value for x and y:");
    scanf("%d %d", &x, &y);

    Add(&x, &y);

    return 0;
}

void Add(int *a, int *b)
{
    printf("Addition is: %d", (*a + *b));
}
