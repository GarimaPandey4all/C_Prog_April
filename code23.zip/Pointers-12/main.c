#include <stdio.h>
#include <stdlib.h>

union Date {

    int day;
    int month;
    int year;
};
//}date1, date2, date3;

union Date date1, *pdate;

int main()
{
  //union Date date1;
  pdate = &date1;

  pdate->day = 20;
  printf("Day = %d\n", pdate->day);
  pdate->month = 5;
  printf("Month = %d\n", pdate->month);
  pdate->year = 2021;
  printf("Year = %d\n", pdate->year);

 // printf("Day = %d, Month = %d, Year = %d\n", date1.day, date1.month, date1.year);

    return 0;
}
