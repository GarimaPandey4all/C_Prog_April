#include <stdio.h>
#include <stdlib.h>

struct Student {
    int id;
    int age;
    char *name;
}S1;

int main()
{
    S1.id = 1;
    S1.age = 20;
    S1.name = "Brain";

    printf("Id is: %d\n", S1.id);
    printf("Age is: %d\n", S1.age);
    printf("Name is: %s\n", S1.name);

    return 0;
}
