#include <stdio.h>
#include <stdlib.h>

/*
    String Pre-Built Functions

    1. String Length
    2. String Copy
    3. String Concatenate/Joining
    4. String Compare
    5. String Uppercase
    6. String Lowercase
*/

int main()
{
    char str[10];
    char name[10];

    printf("enter any string:");
    gets(str);

    printf("String Length is: %d\n", strlen(str));


    printf("string 1 is copying in string 2: %s\n", strcpy(name, str));

    printf("string 1 is copying in string 2: %s\n", strcpy(name, "Welcome"));

    return 0;
}
