#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter First Name:");
    gets(str1);

    printf("Enter Last Name:");
    gets(str2);

    printf("Your Full Name is: %s", strcat(str1, str2));

    return 0;
}
