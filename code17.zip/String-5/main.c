#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[] = "Wel";
    int i;

    for(i = 0; str[i] != '\0'; i++)
    {

    }

    printf("String Length is: %d", i);

    return 0;
}
