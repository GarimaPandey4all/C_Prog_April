#include <stdio.h>
#include <stdlib.h>


int main()
{
    char str1[10];
    char str2[10];

    printf("Enter string-1:");
    gets(str1);

    printf("Enter string-2:");
    gets(str2);

    printf("Uppercase is: %s\n", strupr(str1));

    printf("Lowercase is: %s\n", strlwr(str2));

    if(strcmp(str1, str2) == 0)
    {
        printf("Strings are same\n");
    }
    else
    {
        printf("Strings are not same\n");
    }

    return 0;
}
