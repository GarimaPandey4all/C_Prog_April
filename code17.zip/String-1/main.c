#include <stdio.h>
#include <stdlib.h>

int main()
{
    char name[10];

    printf("Enter your name:");
    //scanf("%s", &name);
    gets(name); // read input

    //puts(name); print output
    printf("Your name is: %s", name);

    return 0;
}
