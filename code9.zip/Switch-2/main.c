#include <stdio.h>
#include <stdlib.h>

int main()
{
    int choice;
    int a, b;

    //while(1) //loop - repeatition
    for(;;)
    {
    printf("\n\nPress 1. X-OR Operator\n");
    printf("Press 2. Even-Odd\n");
    printf("Press 3. Largest Number\n");
    printf("Press 4. Left Shift\n");
    printf("Press 5. Exit");

    printf("\n\nEnter your choice:");
    scanf("%d", &choice);

    switch(choice)
    {
    case 1:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        printf("X-OR is: %d", (a ^ b));
        break;

    case 2:
        printf("Enter any number:");
        scanf("%d", &a);

        ((a % 2) == 0) ? printf("Number is Even") : printf("Number is Odd");
        break;

    case 3:
        printf("Enter value for a and b:");
        scanf("%d %d", &a, &b);

        (a > b) ? printf("a is greater"): printf("b is greater");
        break;

    case 4:
        printf("Enter any number:");
        scanf("%d", &a);

        printf("Left Shift is: %d", (a<<1));
        break;

    case 5:
        exit(0); //exit the program

    default:
        printf("Invalid Choice");
    }

    }


    return 0;
}
