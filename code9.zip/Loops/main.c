#include <stdio.h>
#include <stdlib.h>

/*
    Loops:

    1. for loop
    2. while loop
    3. do-while loop
*/


int main()
{
    int i;

    for(i = 1; i <= 10; i++)
    {
        printf("Hello World\n");
    }

    return 0;
}
