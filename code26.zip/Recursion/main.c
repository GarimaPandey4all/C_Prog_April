#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;

    x = func(5); // function calling

    printf("Sum of digits:%d", x);

    return 0;
}

int func(int a)
{
    int sum;

    if(a == 1) // base condition or stop condition
    {
        return a;
    }
    //processing logic
    sum = a + func(a - 1); // func(a - 1) - recursive call
}
