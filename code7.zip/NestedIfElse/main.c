#include <stdio.h>
#include <stdlib.h>

int main()
{
    int age = 20;

    if(age == 25)
    {
        if(age < 30)
        {
            printf("Age is Valid");
        }
        else
        {
            printf("Age is Invalid");
        }
    }
    else
    {
        printf("Age is not suitable");
    }

    return 0;
}
