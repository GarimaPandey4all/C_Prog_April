#include <stdio.h>
#include <stdlib.h>

int main()
{
    float hindi, english, history, science, maths, sum = 0, percentage;

    printf("Enter your marks:");
    scanf("%f %f %f %f %f", &hindi, &english, &history, &science, &maths);

    sum = hindi + english + history + science + maths;

    printf("Total Marks is: %f\n", sum);

    percentage = sum / 5;

    printf("Percentage is: %f\n", percentage);

    if(percentage >= 50 && percentage <= 60)
    {
        printf("Grade D");
    }
    else if(percentage >= 60 && percentage <= 70)
    {
        printf("Grade C");
    }
    else if(percentage >= 70 && percentage <= 80)
    {
        printf("Grade B");
    }
    else if(percentage >= 80 && percentage <= 100)
    {
        printf("Grade A");
    }

    else {
        printf("Fail...");
    }

    return 0;
}
