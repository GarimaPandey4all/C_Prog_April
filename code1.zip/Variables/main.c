#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;
    const int b = 12; // fixed value

    printf("A is: %d\n", a);

    a = 50;

    printf("A is: %d\n", a);

    //b = 15; // error

    printf("B is: %d", b);

    return 0;
}
