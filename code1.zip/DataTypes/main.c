#include <stdio.h>
#include <stdlib.h>

/*
    8 Bits = 1 byte
    2 bytes = 16 bits
    4 bytes = 32 bits

*/

int main()
{
    int a = 10; // 2(16-bit compiler) or 4(32-bit compiler) bytes
    char ch = 'F'; // 1 byte
    float b = 25.67f; // 4 bytes
    double c = 36.78; // 8 bytes

    printf("A is: %d\n", a);
    printf("Ch is: %c\n", ch);
    printf("B is: %.2f\n", b);
    printf("C is: %lf\n", c); // lf: long float

    printf("Int is: %d\n", sizeof(a));
    printf("Char is: %d\n", sizeof(ch));
    printf("Float is: %d\n", sizeof(b));
    printf("Double is: %d\n", sizeof(c));

    printf("Int is: %d\n", sizeof(int));
    printf("Char is: %d\n", sizeof(char));
    printf("Float is: %d\n", sizeof(float));
    printf("Double is: %d\n", sizeof(double));


    return 0;
}
