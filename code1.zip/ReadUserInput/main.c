#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;

    printf("Enter any value for a:");
    scanf("%d", &a);

//    %d: Format Specifier
//    &: Address of Operator

    printf("Enter any value for b:");
    scanf("%d", &b);

    c = a + b;

    printf("Addition of a and b is:%d", c);

    getch();

    return 0;
}
