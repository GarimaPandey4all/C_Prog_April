#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;
    const float pi = 3.14;

    printf("A is: %d\n", a);

    a = 40;

    printf("A is: %d\n", a);

    //pi = 3.67; // error

    printf("Pi is: %f\n", pi);

    return 0;
}
