#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
    printf("Subtraction is: %d\n", (a - b));
    printf("Multiplication is: %d\n", (a * b));
    printf("Division is: %d\n", (a / b));

    printf("Modulus is: %d\n", (a % b));  // a = 4, b = 5

    //Pre and Post Increment
    printf("Pre-Increment is: %d\n", (++a));
    printf("Post-Increment is: %d\n", (a++));
    printf("A is: %d\n", a);

    //Pre and Post Decrement
    printf("Pre-Decrement is: %d\n", (--a));
    printf("Post-Decrement is: %d\n", (a--));
    printf("A is: %d", a);

    return 0;
}
