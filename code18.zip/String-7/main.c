#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str[] = "How are you?";
    int i, word = 1;

    for(i = 0; str[i] != '\0'; i++)
    {
        if(str[i] == ' ')
        {
            word++;
        }
    }

    printf("Word Count of the given string is: %d", word);

    return 0;
}
