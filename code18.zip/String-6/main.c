#include <stdio.h>
#include <stdlib.h>

/*
    a - 97
    A - 65
        32

*/

int main()
{
    char str[] = "WELCOME";
    int i;

//    for(i = 0; str[i] != '\0'; i++)
//    {
//        str[i] = str[i] - 32;
//    }
//
//    printf("Uppercase is: %s", str);

    for(i = 0; str[i] != '\0'; i++)
    {
        str[i] = str[i] + 32;
    }

    printf("Lowercase is: %s", str);

    return 0;
}
