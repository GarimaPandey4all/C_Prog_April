#include <stdio.h>
#include <stdlib.h>

union Date {

    int day;
    int month;
    int year;
};
//}date1, date2, date3;

union Date date1;

int main()
{
  //union Date date1;

  date1.day = 20;
  printf("Day = %d\n", date1.day);
  date1.month = 5;
  printf("Month = %d\n", date1.month);
  date1.year = 2021;
  printf("Year = %d\n", date1.year);

 // printf("Day = %d, Month = %d, Year = %d\n", date1.day, date1.month, date1.year);

    return 0;
}
