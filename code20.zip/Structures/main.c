#include <stdio.h>
#include <stdlib.h>

struct Date {

    int day;
    int month;
    int year;
};
//}date1, date2, date3;

struct Date date1;

int main()
{
  //struct Date date1;

  date1.day = 20;
  date1.month = 5;
  date1.year = 2021;

  printf("Day = %d, Month = %d, Year = %d\n", date1.day, date1.month, date1.year);

    return 0;
}
