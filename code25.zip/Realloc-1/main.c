#include <stdio.h>
#include <stdlib.h>

//Realloc: Re-Allocation

int main()
{
    char *str;

    str = (char *)malloc(15); // 15 bytes

    //string copy
    strcpy(str, "Jason");

    printf("String = %s and Address = %u\n", str, str);

    //Reallocation Memory
    str = realloc(str, 25);

    //String Conatenation
    strcat(str, ".com");

    printf("String = %s and Address = %u\n", str, str);

    free(str);
    str = NULL;

    return 0;
}
