#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp = NULL;

    fp = fopen("file.txt", "a");
    // a- append mode: create and write at the end in existing as well.

    if(fp != NULL)
    {
        fprintf(fp, "%s %d\n\n", "Hi... This is example-2", 555);
    }

    fclose(fp);
    fp = NULL;

    return 0;
}
