#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a = 10;

    a += 30; // a = a + 30;

    a /= 40; // a = a / 40;

    printf("Address of a: %d", &a);

    return 0;
}
