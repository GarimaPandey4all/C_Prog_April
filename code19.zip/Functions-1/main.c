#include <stdio.h>
#include <stdlib.h>

/*
    Functions: Procedure or Particular Task

    Function provides reuseability

    Function has 4 types:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Function with arguments and with return value

*/

//1. Function without arguments and without return value

//Function Declaration
void Add(); // void = null or empty

int main()
{
    //Function Calling
    Add();
    Add();

    return 0;
}

//Function Definition
void Add()
{
    int a, b;

    printf("Enter any value for a and b:\n");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", (a + b));
}
