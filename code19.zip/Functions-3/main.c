#include <stdio.h>
#include <stdlib.h>

//2. Function without arguments and with return value


int Add();

int main()
{
    int result = Add();

    printf("Addition is: %d", result);

    return 0;
}

int Add()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    //printf("Addition is: %d\n", (a + b));

    return (a + b);

    //return 0;
}
