#include <stdio.h>
#include <stdlib.h>

//4. Function with arguments and with return value


int Add(int a, int b);

int main()
{
    int result = Add(10, 20);

    printf("Addition is: %d", result);

    return 0;
}

int Add(int a, int b)
{
    return (a + b);
}
