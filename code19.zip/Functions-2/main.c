#include <stdio.h>
#include <stdlib.h>

//2. Function with arguments and without return value


void Add(int a, int b);

int main()
{
    Add(10, 20); // 10 and 20- actual arguments

    return 0;
}

//Function Prototype

void Add(int a, int b) // int a and int b - formal arguments / parameters
{
    printf("Addition is: %d\n", (a + b));
}
