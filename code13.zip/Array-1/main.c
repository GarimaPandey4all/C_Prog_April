#include <stdio.h>
#include <stdlib.h>

//array = store multiple values in a single variable

int main()
{
    int i;

    //int lists[5]; // declaration
    //[] - subscript operator

    //Traditional Way of Initialization
    int lists[5] = {10, 20, 30, 40, 50}; // declaration and initialization

    //Compile Time Initialization
    int numbers[] = {1, 2, 3, 4, 5};

    printf("First value of array:%d\n", lists[0]);

    printf("Third value of array:%d\n", lists[2]);

    printf("Values in Array are:\n");
    for(i = 0; i < 5; i++)
    {
        printf("%d\t", numbers[i]); // \n- new line, \t- space like tab
    }

    return 0;
}
