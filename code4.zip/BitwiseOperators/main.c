#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("And Bitwise Operator: %d\n", (a & b));
    printf("Or Bitwise Operator: %d\n", (a | b));
    printf("X-Or Bitwise Operator: %d\n", (a ^ b));
    printf("Left Shift Bitwise Operator: %d\n", (a<<1));
    printf("Right Shift Bitwise Operator: %d\n", (a>>3));

    return 0;
}
