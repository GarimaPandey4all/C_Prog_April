#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("AND Operator is: %d\n", (a > b && b < 10));
    printf("OR Operator is: %d\n", (a > b || b < 10));
    printf("NOT Operator is: %d\n", !(a > b || b < 10));

    return 0;
}
