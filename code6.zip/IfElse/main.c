#include <stdio.h>
#include <stdlib.h>

/*
    Decision Making Statements / Conditional Statements

    1. If-Else
    2. If-Else if-Else
    3. Conditional Operator
    4. Switch

*/


int main()
{
    int a, b;

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    if(a > b)
    {
        printf("A is Greater");
    }
    else
    {
        printf("B is Greater");
    }

    return 0;
}
